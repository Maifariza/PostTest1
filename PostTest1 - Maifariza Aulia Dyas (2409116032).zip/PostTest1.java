package com.mycompany.posttest1;

import java.util.ArrayList;
import java.util.Scanner;

public class PostTest1 {

    static class BarangAntik {
        int id;
        String nama;
        String kategori;
        String asal;
        int tahun;
        String material;
        String kondisi;
        String sumber;
        double hargaPerolehan;

        BarangAntik(int id, String nama, String kategori, String asal, int tahun,
                    String material, String kondisi, String sumber, double hargaPerolehan) {
            this.id = id;
            this.nama = nama;
            this.kategori = kategori;
            this.asal = asal;
            this.tahun = tahun;
            this.material = material;
            this.kondisi = kondisi;
            this.sumber = sumber;
            this.hargaPerolehan = hargaPerolehan;
        }
    }

    // ====== Penyimpanan data ======
    static ArrayList<BarangAntik> koleksi = new ArrayList<>();
    static int nextId = 1;
    static Scanner in = new Scanner(System.in);

    public static void main(String[] args) {
        koleksi.add(new BarangAntik(nextId++, "Vas Dinasti Ming", "Keramik", "Tiongkok", 1560,
                "Porselen", "Baik", "Lelang", 120_000_000));
        koleksi.add(new BarangAntik(nextId++, "Koin Perak VOC", "Koin", "Nusantara", 1750,
                "Perak", "Sedang", "Warisan", 8_500_000));
        koleksi.add(new BarangAntik(nextId++, "Meja Ukir Jepara", "Mebel", "Jepara", 1800,
                "Kayu Jati", "Baik", "Warisan", 55_000_000));
        koleksi.add(new BarangAntik(nextId++, "Naskah Kuno Sansekerta", "Naskah", "India", 1200,
                "Lontar", "Sedang", "Hibah", 200_000_000));
        koleksi.add(new BarangAntik(nextId++, "Guci Dinasti Qing", "Keramik", "Tiongkok", 1700,
                "Porselen", "Baik", "Lelang", 150_000_000));
        koleksi.add(new BarangAntik(nextId++, "Pedang Samurai Katana", "Senjata", "Jepang", 1600,
                "Baja", "Baik", "Pembelian", 250_000_000));
        koleksi.add(new BarangAntik(nextId++, "Gucci Eropa Abad 18", "Perhiasan", "Prancis", 1780,
                "Emas", "Baik", "Lelang", 95_000_000));
        koleksi.add(new BarangAntik(nextId++, "Jam Saku Victoria", "Jam", "Inggris", 1890,
                "Perak", "Sedang", "Pembelian", 22_000_000));
        koleksi.add(new BarangAntik(nextId++, "Piring Keramik Belanda", "Keramik", "Belanda", 1745,
                "Keramik", "Rusak", "Warisan", 15_000_000));
        koleksi.add(new BarangAntik(nextId++, "Kalung Manik-Manik", "Perhiasan", "Kalimantan", 1600,
                "Batu Alam", "Baik", "Hibah", 18_000_000));

        while (true) {
            tampilkanMenu();
            System.out.print("Pilih menu [1-6] : ");
            String pilih = in.nextLine().trim();

            if (pilih.equals("1")) {
                tambahBarang();
            } else if (pilih.equals("2")) {
                tampilkanSemua();
            } else if (pilih.equals("3")) {
                perbaruiBarang();
            } else if (pilih.equals("4")) {
                hapusBarang();
            } else if (pilih.equals("5")) {
                cariBarang();
            } else if (pilih.equals("6")) {
                System.out.print("Apakah yakin kamu ingin keluar? (y/n) : ");
                String konfirmasi = in.nextLine().trim().toLowerCase();
                if (konfirmasi.equals("y")) {
                    System.out.println("\n");
                    System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
                    System.out.println("  Terima kasih Telah Menggunakan Program AntikAesthetic!! ");
                    System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
                    break;
                } else {
                    System.out.println("\n<<<<< Kembali ke menu utama AntikAesthetic >>>>>");
                }
            } else {
                System.out.println("Pilihan tidak valid.");
            }

            enterUntukLanjut();
        }
    }

    // MENU
    static void tampilkanMenu() {
        System.out.println("\n===============================================================");
        System.out.println("||          ^^ SELAMAT DATANG DI AntikAesthetic ^^           ||");
        System.out.println("===============================================================");
        System.out.println("------------------------- MENU UTAMA --------------------------");
        System.out.println("||  1. Tambah Barang                                         ||");
        System.out.println("||  2. Tampilkan Semua Barang                                ||");
        System.out.println("||  3. Perbarui Barang (berdasarkan ID)                      ||");
        System.out.println("||  4. Hapus Barang (berdasarkan ID)                         ||");
        System.out.println("||  5. Cari Barang (nama/kategori/asal)                      ||");
        System.out.println("||  6. Keluar                                                ||");
        System.out.println("===============================================================");
    }

    // CREATE
    static void tambahBarang() {
        System.out.println("\n........................................");
        System.out.println("      TAMBAH BARANG AntikAesthetic     ");
        System.out.println("........................................");
        String nama = inputString("Nama barang");
        String kategori = inputString("Kategori (mis. Keramik/Koin/Lukisan/Perhiasan)");
        String asal = inputString("Asal/Asal-usul");
        int tahun = inputInt("Tahun pembuatan/periode (angka)", 0, 3000);
        String material = inputString("Material/Bahan");
        String kondisi = inputString("Kondisi (Baik/Sedang/Rusak/Direstorasi)");
        String sumber = inputString("Sumber perolehan (Pembelian/Hibah/Lelang/Warisan)");
        double harga = inputDouble("Harga perolehan (angka, bisa 0 jika tidak diketahui)", 0, Double.MAX_VALUE);

        BarangAntik b = new BarangAntik(nextId++, nama, kategori, asal, tahun, material, kondisi, sumber, harga);
        koleksi.add(b);
        System.out.println("\n Berhasil menambahkan barang dengan ID: " + b.id);
    }

    // READ
    static void tampilkanSemua() {
        System.out.println("\n+-----+-----+-----+-----+-----+-----+-----+ DAFTAR KOLEKSI BARANG AntikAesthetic  +-----+-----+-----+-----+-----+-----+-----+");
        System.out.println("............................................................................................................................");
        if (koleksi.isEmpty()) {
            System.out.println("Oops.. belum ada data.");
            return;
        }

        System.out.printf(" %-4s | %-22s | %-10s | %-10s | %-5s | %-10s | %-12s | %-10s | %-12s%n ",
                "ID", "Nama", "Kategori", "Asal", "Thn", "Material", "Kondisi", "Sumber", "Harga");
        System.out.println("----+------------------------+------------+------------+-------+------------+--------------+-------------+----------------");

        for (BarangAntik b : koleksi) {
            System.out.printf("%-4d | %-22s | %-10s | %-10s | %-5d | %-10s | %-12s | %-10s | Rp. %,.0f%n",
                    b.id, potong(b.nama,22), potong(b.kategori,10), potong(b.asal,10), b.tahun,
                    potong(b.material,10), potong(b.kondisi,12), potong(b.sumber,10), b.hargaPerolehan);
        }
    }

    // UPDATE
    static void perbaruiBarang() {
        System.out.println("\n ********** PERBARUI BARANG (berdasarkan ID) **********");
        int id = inputInt("Masukkan ID yang akan diperbarui", 1, Integer.MAX_VALUE);
        BarangAntik b = cariById(id);
        if (b == null) {
            System.out.println("Whoop... Data dengan ID " + id + " tidak ditemukan.");
            return;
        }

        System.out.println("Kosongkan input (tekan Enter) jika ingin mempertahankan nilai lama");
        System.out.println("..........................................................");

        String nama = inputStringOpsional("Nama barang", b.nama);
        String kategori = inputStringOpsional("Kategori", b.kategori);
        String asal = inputStringOpsional("Asal/Asal-usul", b.asal);
        Integer tahun = inputIntOpsional("Tahun (angka)", b.tahun, 0, 3000);
        String material = inputStringOpsional("Material/Bahan", b.material);
        String kondisi = inputStringOpsional("Kondisi", b.kondisi);
        String sumber = inputStringOpsional("Sumber perolehan", b.sumber);
        Double harga = inputDoubleOpsional("Harga perolehan (angka)", b.hargaPerolehan, 0, Double.MAX_VALUE);

        b.nama = nama;
        b.kategori = kategori;
        b.asal = asal;
        b.tahun = tahun;
        b.material = material;
        b.kondisi = kondisi;
        b.sumber = sumber;
        b.hargaPerolehan = harga;

        System.out.println("....... Data ID " + id + " berhasil diperbarui .......");
    }

    // DELETE
    static void hapusBarang() {
        System.out.println("\n>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<");
        System.out.println("      HAPUS BARANG AntikAesthetic       ");
        System.out.println("--------- Cari Berdasarkan ID --------");
        System.out.println(">>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<");
        int id = inputInt("Masukkan ID yang akan dihapus", 1, Integer.MAX_VALUE);
        int idx = indexById(id);
        if (idx == -1) {
            System.out.println("Data dengan ID " + id + " tidak ditemukan.");
            return;
        }
        System.out.print("Yakin hapus ID " + id + " (y/n)? ");
        String ya = in.nextLine().trim().toLowerCase();
        if (ya.equals("y")) {
            koleksi.remove(idx);
            System.out.println("~~~~~~~~ Data ID " + id + " telah dihapus ~~~~~~~~");
        } else {
            System.out.println(" >>>>> Dibatalkan <<<<<");
        }
    }

    // SEARCH
    static void cariBarang() {
        System.out.println("\n==============================================");
        System.out.println("          CARI BARANG AntikAesthetic          ");
        System.out.println("==============================================");
        String key = inputString("Kata kunci").toLowerCase();

        ArrayList<BarangAntik> hasil = new ArrayList<>();
        for (BarangAntik b : koleksi) {
            if (b.nama.toLowerCase().contains(key) ||
                b.kategori.toLowerCase().contains(key) ||
                b.asal.toLowerCase().contains(key)) {
                hasil.add(b);
            }
        }

        if (hasil.isEmpty()) {
            System.out.println("Oops.. Tidak ada hasil untuk: " + key);
            return;
        }

        System.out.printf("%-4s | %-22s | %-10s | %-10s | %-5s | %-10s | %-12s | %-10s | %-12s%n",
                "ID", "Nama", "Kategori", "Asal", "Thn", "Material", "Kondisi", "Sumber", "Harga");
        System.out.println("-----+------------------------+------------+------------+------+------------+--------------+------------+--------------");
        for (BarangAntik b : hasil) {
            System.out.printf("%-4d | %-22s | %-10s | %-10s | %-5d | %-10s | %-12s | %-10s | Rp%,.0f%n",
                    b.id, potong(b.nama,22), potong(b.kategori,10), potong(b.asal,10), b.tahun,
                    potong(b.material,10), potong(b.kondisi,12), potong(b.sumber,10), b.hargaPerolehan);
        }
    }

    // Utilitas
    static BarangAntik cariById(int id) {
        for (BarangAntik b : koleksi) {
            if (b.id == id) return b;
        }
        return null;
    }

    static int indexById(int id) {
        for (int i = 0; i < koleksi.size(); i++) {
            if (koleksi.get(i).id == id) return i;
        }
        return -1;
    }

    static String potong(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max-1) + "…";
    }

    static void enterUntukLanjut() {
        System.out.print("\n~ Tekan Enter untuk melanjutkan...");
        in.nextLine();
    }

    // Input helper & validasi
    static String inputString(String label) {
        while (true) {
            System.out.print(label + " : ");
            String s = in.nextLine().trim();
            if (!s.isEmpty()) return s;
            System.out.println("Input tidak boleh kosong.");
        }
    }

    static int inputInt(String label, int min, int max) {
        while (true) {
            try {
                System.out.print(label + " : ");
                String s = in.nextLine().trim();
                int val = Integer.parseInt(s);
                if (val < min || val > max) {
                    System.out.println("Harus di antara " + min + " dan " + max + ".");
                } else {
                    return val;
                }
            } catch (NumberFormatException e) {
                System.out.println("Harus berupa angka.");
            }
        }
    }

    static double inputDouble(String label, double min, double max) {
        while (true) {
            try {
                System.out.print(label + " : ");
                String s = in.nextLine().trim();
                double val = Double.parseDouble(s);
                if (val < min || val > max) {
                    System.out.println("Harus di antara " + min + " dan " + (max==Double.MAX_VALUE?"tak hingga":max) + ".");
                } else {
                    return val;
                }
            } catch (NumberFormatException e) {
                System.out.println("Harus berupa angka (boleh desimal).");
            }
        }
    }

    static String inputStringOpsional(String label, String lama) {
        System.out.print(label + " [" + lama + "] : ");
        String s = in.nextLine().trim();
        return s.isEmpty() ? lama : s;
    }

    static Integer inputIntOpsional(String label, int lama, int min, int max) {
        while (true) {
            System.out.print(label + " [" + lama + "] : ");
            String s = in.nextLine().trim();
            if (s.isEmpty()) return lama;
            try {
                int val = Integer.parseInt(s);
                if (val < min || val > max) {
                    System.out.println("Harus di antara " + min + " dan " + max + ".");
                } else {
                    return val;
                }
            } catch (NumberFormatException e) {
                System.out.println("Harus berupa angka.");
            }
        }
    }

    static Double inputDoubleOpsional(String label, double lama, double min, double max) {
        while (true) {
            System.out.print(label + " [Rp" + String.format("%,.0f", lama) + "] : ");
            String s = in.nextLine().trim();
            if (s.isEmpty()) return lama;
            try {
                double val = Double.parseDouble(s);
                if (val < min || val > max) {
                    System.out.println("Harus di antara " + min + " dan " + (max==Double.MAX_VALUE?"tak hingga":max) + ".");
                } else {
                    return val;
                }
            } catch (NumberFormatException e) {
                System.out.println("Harus berupa angka (boleh desimal).");
            }
        }
    }
}